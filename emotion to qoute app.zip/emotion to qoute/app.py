from flask import Flask, render_template, request

app = Flask(__name__)

quotes = {
    "happy": "Happiness is a journey, not a destination.",
    "sad": "Sometimes you have to feel the sadness to know the happiness.",
    "angry": "For every minute you are angry, you lose sixty seconds of peace.",
    "motivated": "Success is not final, failure is not fatal: It is the courage to continue that counts.",
    "love": "Where there is love, there is life."
}

@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        emotion = request.form["emotion"]
        quote = quotes.get(emotion.lower(), "No quote found for this emotion.")
        return render_template("quote.html", emotion=emotion.capitalize(), quote=quote)
    return render_template("index.html")

if __name__ == "__main__":
    app.run(debug=True)
